/* This source works around VS6 projects not having separate
   intermediate file directories.  The corresponding source is
   supposed to be built in more than one target with different
   preprocessor definitions.  */
#include "print-rtl.c"
