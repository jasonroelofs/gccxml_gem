#ifndef __SGI_STL_INTERNAL_NUMERIC_FACETS_H_GCCXML
#define __SGI_STL_INTERNAL_NUMERIC_FACETS_H_GCCXML

__STL_BEGIN_NAMESPACE

template<class T>  class numeric_limits;

__STL_END_NAMESPACE

#include_next <stl_numeric_facets.h>

#endif

