#ifndef __STL_CONFIG_H_GCCXML
#define __STL_CONFIG_H_GCCXML

#include <gccxml_mpro_internals.h>

#include_next <stl_config.h>

#endif

