#ifdef __APPLE__
# include "gccxml_apple_emmintrin.h"
#else
# include "gccxml_gnu_emmintrin.h"
#endif
